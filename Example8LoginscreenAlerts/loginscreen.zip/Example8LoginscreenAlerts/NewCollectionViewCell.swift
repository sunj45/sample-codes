//
//  NewCollectionViewCell.swift
//  Example8LoginscreenAlerts
//
//  Created by CEPL on 08/06/22.
//

import UIKit

class NewCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
}
